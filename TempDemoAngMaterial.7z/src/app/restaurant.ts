export interface Restaurant {
  id: number;
  name: string;
  owner: string;
  mobile: string;
  email: string;
  location: string;
  rating: number;
}
